package org.bajaj;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang.RandomStringUtils;

import java.io.FileReader;
import java.io.IOException;

import static org.bajaj.Utils.findDestinationValue;


public class Main {

    public static void main(String[] args) {
        if (args.length != 2) {
            System.out.println("Invalid program args.");
            System.exit(1);
        }

        String prnNumber = args[0].toLowerCase().replaceAll("\\s+","");
        String jsonFilePath = args[1];

        String destinationValue = null;
        try (FileReader reader = new FileReader(jsonFilePath)) {
            JsonElement jsonElement = JsonParser.parseReader(reader);
            destinationValue = findDestinationValue(jsonElement);
        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }

        if (destinationValue == null) {
            System.out.println("key not found.");
            System.exit(1);
        }
        int randomStringlen = 8;
        String randomString = RandomStringUtils.randomAlphanumeric(randomStringlen);
        String md5Hash = DigestUtils.md5Hex(prnNumber + destinationValue + randomString);
        System.out.println(md5Hash + ";" + randomString);
    }


}
