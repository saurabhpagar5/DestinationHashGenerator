package org.bajaj;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.util.Map;

public class Utils {
    static String findDestinationValue(JsonElement element) {
        if (element.isJsonObject()) {
            JsonObject jsonObject = element.getAsJsonObject();
            if (jsonObject.has("destination")) {
                return jsonObject.get("destination").getAsString();
            }
            for (Map.Entry<String, JsonElement> entry : jsonObject.entrySet()) {
                String value = findDestinationValue(entry.getValue());
                if (value != null) {
                    return value;
                }
            }
        } else if (element.isJsonArray()) {
            for (JsonElement item : element.getAsJsonArray()) {
                String value = findDestinationValue(item);
                if (value != null) {
                    return value;
                }
            }
        }
        return null;
    }
}
